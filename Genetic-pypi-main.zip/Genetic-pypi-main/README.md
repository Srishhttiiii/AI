# Genetic-pypi


We first here have a simple example of genetic algorithm (genetic_algorithm.py)


We then have then have the actual library containing, the Linear and Logistic classes (genetic_library.py)


We then subsequently have the runner files and their respective loss function curves (Runner and loss files)
